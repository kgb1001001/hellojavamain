public class HelloJavaMain {
public static void main(String[] args) {
	for (int i=0; i<1000; i++) {
	System.out.println("It worked!  Hello World!");
	try {
		Thread.sleep(1000);
	 } catch (InterruptedException e) {
	// This should not happen
		e.printStackTrace();
	} 
	}
}
}